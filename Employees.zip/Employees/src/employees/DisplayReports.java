package employees;

public class DisplayReports extends JasperReports {

    public void showEmployees() {
        //m_report_source = "rptEmployees.jrxml";
        String m_sql_stmt = "SELECT * FROM employees ORDER BY employee_id";
        showReport();
    }

    private void showReport() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
