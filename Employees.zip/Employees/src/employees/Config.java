package employees;

public class Config {

    public static final String Nama_Database = "mahasiswa_uas";
    public static final String Server = "localhost";
    public static final String User = "root";
    public static final String Password = "";

    public static final String connection_url = "jdbc:mysql://" + Nama_Database + "/" + Server;
}
